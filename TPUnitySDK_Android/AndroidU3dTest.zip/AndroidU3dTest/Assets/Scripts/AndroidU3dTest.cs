﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TP;
using UnityEngine.UI;

public class AndroidU3dTest : MonoBehaviour
{
    TPSDK tpSDK;
   
    void Start()
    {
        tpSDK = new TPSDK("MainCamera");
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnGUI()
    {

        if (GUI.Button(new Rect(100, 100, 250,100), "authLogin"))
        {
            authLogin();
        }

        if (GUI.Button(new Rect(100, 250, 250, 100), "transfer"))
        {
            transfer();
        }

        if (GUI.Button(new Rect(100, 400, 250, 100), "pushTransaction"))
        {
            pushTransaction();
        }

        if (GUI.Button(new Rect(100, 700, 250, 100), "getAccount"))
        {
            getAccount();
        }

        if (GUI.Button(new Rect(100, 1200, 250, 100), "getTableRows"))
        {
            getTableRows();
        }

        if (GUI.Button(new Rect(100, 1500, 250, 100), "getCurrencyBalance"))
        {
            getCurrencyBalance();
        }

        if (GUI.Button(new Rect(100, 1800, 250, 100), "sign"))
        {
            sign();
        }


    }

    public void authLogin()
    {
        string authLoginParam = "{\n" +
                       " \"protocol\": \"TokenPocket\",\n" +
                       " \"version\": \"1.0\",\n" +
                       " \"dappName\": \"EOS Knights\",\n" +
                       " \"dappIcon\": \"https://eosknights.io/img/icon.png\",\n" +
                       " \"action\": \"login\",\n" +
                       " \"actionId\": \"web-db4c5466-1a03-438c-90c9-2172e8becea5\",\n" +
                       " \"callbackUrl\": \"\",\n" +
                       " \"expired\": 1542392547,\n" +
                       " \"memo\": \"EOS Knights\"\n" +
                       "}";
        tpSDK.authLogin(authLoginParam);
     
    }

    public void transfer()
    {
        string transferParam = "{\n" +
                "\t\"protocol\": \"TokenPocket\",\n" +
                "\t\"version\": \"1.0\",\n" +
                "\t\"dappName\": \"Newdex\",\n" +
                "\t\"dappIcon\": \"https://newdex.io/static/logoicon.png\",\n" +
                "\t\"action\": \"transfer\",\n" +
                "\t\"from\": \"eaccount1234\",\n" +
                "\t\"to\": \"newdexpocket\",\n" +
                "\t\"amount\": 0.0001,\n" +
                "\t\"contract\": \"eosio.token\",\n" +
                "\t\"symbol\": \"EOS\",\n" +
                "\t\"precision\": 4,\n" +
                "\t\"dappData\": \"{\\\"type\\\":\\\"buy-limit\\\",\\\"symbol\\\":\\\"IQ_EOS\\\",\\\"price\\\":\\\"0.00220\\\",\\\"count\\\":50,\\\"amount\\\":0.11}\",\n" +
                "\t\"desc\": \"\",\n" +
                "\t\"expired\": 1535944144181,\n" +
                "\t\"callback\": \"https://newdex.io/api/account/transferCallback?uuid=1-46e023fc-015b-4b76-3809-1cab3fd76d2c\"\n" +
                "}";
        tpSDK.transfer(transferParam);
    }

    public void pushTransaction()
    {
        string actions = "{\n" +
                "\t\"dappName\": \"test\",\n" +
                "\t\"dappIcon\": \"https://newdex.io/static/logoicon.png\",\n" +
                "\t\"action\": \"pushTransaction\",\n" + 
                "\t\"actions\": [{\n" +
                "\t\t\"account\": \"eosio.token\",\n" +
                "\t\t\"name\": \"transfer\",\n" +
                "\t\t\"authorization\": [{\n" +
                "\t\t\t\"actor\": \"eosaccount12\",\n" +
                "\t\t\t\"permission\": \"active\"\n" +
                "\t\t}],\n" +
                "\t\t\"data\": {\n" +
                "\t\t\t\"from\": \"eaccount1234\",\n" +
                "\t\t\t\"to\": \"eaccount1235\",\n" +
                "\t\t\t\"quantity\": \"0.0001 EOS\",\n" +
                "\t\t\t\"memo\": \"jlsdjlsdjf\"\n" +
                "\t\t}\n" +
                "\t}],\n" +
                "\t\"expired\": \"10000000000000\"\n" +
                "}";
        tpSDK.pushTransaction(actions);
    }

    public void sign()
    {
        string signParam =  "{\n" +
                "   \"protocol\": \"TokenPocket\",\n" +
                "    \"version\": \"1.0\",\n" +
                "    \"dappName\": \"Newdex\",\n" +
                "    \"dappIcon\": \"https://newdex.io/static/logoicon.png\",\n" +
                "    \"action\": \"sign\",\n" +
                "    \"actionId\": \"web-99784c28-70f0-49ff-3654-f27b137b3502\",\n" +
                "    \"callbackUrl\": \"https://newdex.io/api/account/walletVerify\",\n" +
                "    \"expired\": 1537157808,\n" +
                "    \"memo\": \"The first gobal decentralized exchange built on EOS\",\n" +
                "    \"message\":\"hello\"\n" +
                "}";
        tpSDK.sign(signParam);
    }


    public void getAccount()
    {
        tpSDK.getAccount("xiaoyuantest");
    }

    public void getTableRows()
    {
        tpSDK.getTableRows("{\"json\": true, \"code\": \"theeosbutton\", \"scope\": \"theeosbutton\",\"table\": \"accstates\",\"lower_bound\": \"10\", \"limit\": 30}");
        Debug.Log("test");
    }

    public void getCurrencyBalance()
    {
        tpSDK.getCurrencyBalance("{\n \"account\": \"xiaoyuantest\",\n \"symbol\": \"EOS\"\n \"code\": \"eosio.token\"\n}");
    }


    //if you want to get result, add the following method to your script
    public void onTpAuthLogin(string data)
    {
        tpSDK.showUnityMsg(data);
    }

    public void onTpTransfer(string data)
    {
        tpSDK.showUnityMsg(data);
    }

    public void onTpPushTransaction(string data)
    {
        tpSDK.showUnityMsg( data);
    }

    public void onTpGetAccount(string data)
    {
        tpSDK.showUnityMsg(data);
    }

    public void onTpGetTableRows(string data)
    {
        tpSDK.showUnityMsg(data);
    }

    public void onTpGetCurrencyBalance(string data)
    {
        tpSDK.showUnityMsg(data);
    }

    public void onTpSign(string data)
    {
        tpSDK.showUnityMsg(data);
    }

}
