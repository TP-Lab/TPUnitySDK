﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TPSDKSpace.TPSDKMain;
using TPSDKSpace.TPObject;


public class TPDemo : MonoBehaviour
{
    private TPSDK tpsdk;

    /// Callback string reference.
    private string cbString;

    private void Awake()
    {
        tpsdk = gameObject.GetComponent<TPSDK>();
        tpsdk.appID = "tpunity";		/// [required]
        tpsdk.callbackTarget = gameObject.name; 	/// [required]
        tpsdk.callbackDelegate = OnTPSDKCallbackHandler;
        Debug.LogFormat("UnityLog__GameObj.name=={0}", tpsdk.callbackTarget);
    }

    private void OnGUI()
    {
        GUIStyle btnstl = new GUIStyle();
        btnstl.normal.textColor = Color.blue;
        btnstl.fontSize = 40;

        if (GUI.Button(new Rect(200, 100, 240, 80), "TPLogin", btnstl))
        {
            TPLoginObj login = new TPLoginObj();
            login.dappName = "Unity3D Demo";
            login.dappIcon = "https://gz.bcebos.com/v1/tokenpocket/temp/mobile_sdk_demo.png";
            tpsdk.SendObj(login);
        }

        if (GUI.Button(new Rect(Screen.width - 350, 100, 240, 80), "TPTransfer", btnstl))
        {
            TPTransferObj transfer = new TPTransferObj();
            transfer.dappName = "Unity3D Demo";
            transfer.dappIcon = "https://gz.bcebos.com/v1/tokenpocket/temp/mobile_sdk_demo.png";
            transfer.to = "clementsign1";
            transfer.amount = "0.001";
            transfer.symbol = "EOS";
            transfer.contract = "eosio.token";
            transfer.precision = "4";
            tpsdk.SendObj(transfer);
        }

        if (GUI.Button(new Rect(200, 240, 240, 80), "TPPushTransaction", btnstl))
        {
            TPPushTransactionObj pushTra = new TPPushTransactionObj();
            pushTra.dappName = "Unity3D Demo";
            pushTra.dappIcon = "https://gz.bcebos.com/v1/tokenpocket/temp/mobile_sdk_demo.png";
            pushTra.actions = "[{\"account\": \"eosio.token\",\"name\": \"transfer\",\"authorization\": [{\"actor\": \"xiaoyuantest\",\"permission\": \"active\"}],\"data\": {\"from\": \"xiaoyuantest\",\"to\": \"clementsign1\",\"quantity\": \"0.0003 EOS\",\"memo\": \"memo string.\"}}]";
            tpsdk.SendObj(pushTra);
        }


        if (this.cbString != null)
        {
            GUIStyle lbstl = new GUIStyle();
            lbstl.normal.textColor = Color.black;
            lbstl.fontSize = 32;
            lbstl.fixedWidth = Screen.width;
            GUI.Label(new Rect(16, 800, Screen.width - 32, 800), cbString, lbstl);
        }
    }

    private void OnTPSDKCallbackHandler(TPResponse resp, string json)
    {
        cbString = json;
        Debug.LogFormat("TPDEMO_TPResponse=\n---------\nresult={0}, \naction={1}, \nsign={2}, \ntxId={3}, \nref={4}\n---------", resp.result, resp.action, resp.sign, resp.txId, resp.Ref);
    }
}
